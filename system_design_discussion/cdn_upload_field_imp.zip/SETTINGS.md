# CDNUploadField — Setup Notes

## 1. Install
```
pip install requests --break-system-packages
```
(Pillow is also required — Django's ImageField validation depends on
it. You almost certainly already have it if you use ImageField anywhere.)

Add to INSTALLED_APPS:
```python
INSTALLED_APPS = [
    ...,
    "cdn_upload",
]
```

## 2. settings.py — one fixed GitHub target per project
```python
from dotenv import load_dotenv
import os

load_dotenv(BASE_DIR / ".env")

CDN_UPLOAD_GITHUB_TOKEN  = os.environ["CDN_UPLOAD_GITHUB_TOKEN"]
CDN_UPLOAD_GITHUB_OWNER  = os.environ["CDN_UPLOAD_GITHUB_OWNER"]
CDN_UPLOAD_GITHUB_REPO   = os.environ["CDN_UPLOAD_GITHUB_REPO"]
CDN_UPLOAD_GITHUB_BRANCH = os.environ.get("CDN_UPLOAD_GITHUB_BRANCH", "main")
```

`.env` (per project, plain filename — the directory already
disambiguates projects, no need for project-named env files):
```
CDN_UPLOAD_GITHUB_TOKEN=ghp_xxxxxxxxxxxx
CDN_UPLOAD_GITHUB_OWNER=your_github_username
CDN_UPLOAD_GITHUB_REPO=your_public_assets_repo
CDN_UPLOAD_GITHUB_BRANCH=main
```

Token scope: a fine-grained PAT limited to that one repo, with
"Contents: Read and write" — avoid classic tokens with blanket `repo`
scope.

## 3. Model usage — this is the whole API
```python
from cdn_upload.fields import CDNUploadField

def event_image_upload_path(instance, filename):
    return f"events/{instance.year.year}"

class EventImage(models.Model):
    year = models.ForeignKey(Year, related_name="images", on_delete=models.CASCADE)
    image_url = CDNUploadField(upload_to=event_image_upload_path)
    description = models.CharField(max_length=255)
```
That's it — no custom form, no custom view, no separate model. A
`ModelForm` (or the Django admin) built against this model automatically
renders a file input. On save, Django:

1. Calls `event_image_upload_path(instance, filename)` to build the
   logical path (e.g. `events/2024/cover.jpg`)
2. Hands that + the file bytes to `GitHubCDNStorage._save()`
3. Which PUTs the file to GitHub's Contents API and returns the full
   jsDelivr URL
4. That URL is what actually lands in the `image_url` database column

One request, one form submission, from the user's point of view it's
an ordinary upload.

## 4. Template usage
```html
{% if image.image_url %}
  <img src="{{ image.image_url }}" alt="{{ image.description }}">
{% endif %}
```
`{{ image.image_url.url }}` also works identically — both resolve to
the same stored CDN URL. Use whichever reads better in context; there's
no functional difference.

## 5. Admin usage
No extra code needed — `CDNUploadField` is a real `ImageField` subclass,
so `ModelAdmin` renders it as a file input automatically. (Per your
call: no thumbnail preview column added.)

## 6. Migrations
Running `makemigrations` after converting an existing `URLField` to
`CDNUploadField` will generate an `AlterField` — this is safe (both are
backed by a plain varchar/text column), but review the generated
migration once before applying it to production data, and back up first
since any schema change deserves that regardless of how safe it looks.

## 7. Things intentionally NOT included yet (flag if you want them)

- **Deletion on GitHub when a row is deleted.** Currently a no-op.
  Possible later: since the URL format is fixed
  (`https://cdn.jsdelivr.net/gh/{owner}/{repo}@{branch}/{path}`), a
  `post_delete` signal could parse the URL back into
  owner/repo/branch/path, fetch the blob's current `sha` via a GET, and
  call GitHub's delete endpoint. Not wired up — deciding to leave stray
  files in the repo is a reasonable default for small CDN-hosted images.
- **width_field / height_field** — unsupported (see fields.py
  docstring); the field never reads the file back from storage.
- **Per-user vs opaque-ID folder naming** — the examples above use
  `instance.user.username` directly. If a given project handles
  anything sensitive, swap to an opaque ID (see prior discussion re:
  public repo browsability) before using this in that project.
