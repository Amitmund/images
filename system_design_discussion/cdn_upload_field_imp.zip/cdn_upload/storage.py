"""
storage.py

A Django Storage backend that commits files to a GitHub repo via the
Contents API and returns a jsDelivr CDN URL as the "name" — meaning the
full URL is what gets stored in the database, not a relative path.

Config comes from settings (one fixed GitHub target per deployment,
per our "each project is its own deployment" conclusion) — no
contextvars, no middleware, no per-request state.

Required settings (typically loaded via python-dotenv in settings.py):
    CDN_UPLOAD_GITHUB_TOKEN   - a fine-grained PAT scoped to one repo
    CDN_UPLOAD_GITHUB_OWNER   - github username or org
    CDN_UPLOAD_GITHUB_REPO   - the public repo used for uploads
    CDN_UPLOAD_GITHUB_BRANCH  - defaults to "main"
"""
import base64
import uuid
import requests
from django.conf import settings
from django.core.files.storage import Storage
from django.utils.text import slugify


class GitHubCDNStorage(Storage):
    """
    _save() does the actual GitHub commit and returns the full jsDelivr
    URL as the value Django will store in the DB column.

    url() and exists() are then just identity/no-op — the "name" IS
    already the URL, so there's nothing left to compute.
    """

    def __init__(self):
        self.token = settings.CDN_UPLOAD_GITHUB_TOKEN
        self.owner = settings.CDN_UPLOAD_GITHUB_OWNER
        self.repo = settings.CDN_UPLOAD_GITHUB_REPO
        self.branch = getattr(settings, "CDN_UPLOAD_GITHUB_BRANCH", "main")

    def _unique_filename(self, name: str) -> str:
        """
        `name` here already includes the upload_to-derived folder, e.g.
        'events/2024/cover.jpg'. We keep the folder, but de-dupe the
        filename itself so two uploads never collide on GitHub.
        """
        folder, _, filename = name.rpartition("/")
        stem, _, ext = filename.rpartition(".")
        stem = slugify(stem) or "file"
        ext = ext.lower() or "bin"
        unique = f"{stem}-{uuid.uuid4().hex[:10]}.{ext}"
        return f"{folder}/{unique}" if folder else unique

    def _save(self, name, content):
        path = self._unique_filename(name)

        content.seek(0)
        raw_bytes = content.read()
        b64_content = base64.b64encode(raw_bytes).decode()

        api_url = (
            f"https://api.github.com/repos/{self.owner}/{self.repo}/contents/{path}"
        )
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        payload = {
            "message": f"Upload {path}",
            "content": b64_content,
            "branch": self.branch,
        }

        resp = requests.put(api_url, json=payload, headers=headers, timeout=20)
        if resp.status_code not in (200, 201):
            raise IOError(
                f"GitHub upload failed ({resp.status_code}): {resp.text[:300]}"
            )

        # Branch-pinned URL: reconstructable, but not needed here since we
        # store the URL itself as the field value rather than rebuilding it.
        cdn_url = (
            f"https://cdn.jsdelivr.net/gh/{self.owner}/{self.repo}"
            f"@{self.branch}/{path}"
        )
        return cdn_url

    def exists(self, name):
        # Always False: uniqueness is handled by the UUID suffix in
        # _save(), not by Django's get_available_name() dedup loop. This
        # also avoids an extra GitHub API call on every single upload.
        return False

    def url(self, name):
        # `name` is already the full CDN URL by the time this is called
        # (it's exactly what _save() returned), so this is an identity
        # passthrough. This is what makes both `{{ obj.field }}` and
        # `{{ obj.field.url }}` work in templates without extra code.
        return name

    def _open(self, name, mode="rb"):
        raise NotImplementedError(
            "GitHubCDNStorage is write-through only. Images are served "
            "directly from jsDelivr, not read back through Django."
        )

    def delete(self, name):
        # Deliberately not implemented yet: deleting requires the blob's
        # current `sha`, and the URL alone doesn't carry that. See
        # SETTINGS.md for the optional deletion approach if you want it.
        pass

    def size(self, name):
        return None
