"""
example_models.py

Two worked examples of upload_to callables — showing that the same
CDNUploadField is reused unchanged, only the folder-grouping logic
differs per model.
"""
from django.db import models
from cdn_upload.fields import CDNUploadField


# ── Example 1: your real model, converted ──────────────────────────────

def event_image_upload_path(instance, filename):
    """
    Groups uploads by year, e.g. 'events/2024/<generated-name>.jpg'.
    Adjust `instance.year.year` to whatever attribute on your Year
    model actually holds the year number (e.g. `.value`, `.label`).
    """
    return f"events/{instance.year.year}"


class Year(models.Model):
    year = models.PositiveIntegerField(unique=True)

    def __str__(self):
        return str(self.year)


class EventImage(models.Model):
    year = models.ForeignKey(Year, related_name="images", on_delete=models.CASCADE)

    # Was: models.URLField(max_length=500, help_text="Enter a valid image URL...")
    image_url = CDNUploadField(
        upload_to=event_image_upload_path,
        verbose_name="Main Image",
        help_text="Upload an image for this event — it will be hosted "
                   "automatically and the link stored here.",
    )

    description = models.CharField(
        max_length=255,
        help_text="A description about this image.",
    )

    def __str__(self):
        return self.description


# ── Example 2: per-user grouping, for comparison ───────────────────────

def profile_avatar_upload_path(instance, filename):
    """
    Groups uploads by username, e.g. 'avatars/amitrout/<generated-name>.png'.
    Same field type as above — only this callable differs.
    """
    return f"avatars/{instance.user.username}"


class Profile(models.Model):
    user = models.OneToOneField("auth.User", on_delete=models.CASCADE)
    avatar = CDNUploadField(
        upload_to=profile_avatar_upload_path,
        blank=True,
        help_text="Upload a profile picture.",
    )
