from django.apps import AppConfig


class CdnUploadConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cdn_upload"
