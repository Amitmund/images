"""
fields.py

CDNUploadField: drop-in replacement for models.ImageField that uploads
to GitHub and stores the resulting jsDelivr CDN URL directly in the
database column (not a relative path).

Usage is identical to ImageField in every way that matters day-to-day:

    class EventImage(models.Model):
        year = models.ForeignKey(Year, related_name='images', on_delete=models.CASCADE)
        image_url = CDNUploadField(
            upload_to=event_image_upload_path,
            verbose_name="Main Image",
            help_text="Upload an image for this event.",
        )

`upload_to` works exactly as it does for any FileField: a string, or a
callable(instance, filename) -> str. This is what determines folder
grouping (per-year, per-user, whatever you need) — see SETTINGS.md for
worked examples of both.

Two ImageField features that are NOT supported and will raise if used,
since they require reading the file back from storage (which this
backend deliberately doesn't do — the image is served straight from
jsDelivr, never re-opened by Django):
    - width_field / height_field
    - anything relying on FieldFile.path (local filesystem path)
"""
from django.db import models

from .storage import GitHubCDNStorage


class CDNUploadField(models.ImageField):
    def __init__(self, *args, **kwargs):
        if kwargs.get("width_field") or kwargs.get("height_field"):
            raise ValueError(
                "CDNUploadField does not support width_field/height_field: "
                "images are served directly from the CDN and are never "
                "re-opened by Django to measure dimensions."
            )

        # URLs are long (owner/repo/branch/folder/filename) — the
        # ImageField default of 100 chars will truncate or reject them.
        kwargs.setdefault("max_length", 500)
        kwargs["storage"] = GitHubCDNStorage()

        super().__init__(*args, **kwargs)

    def deconstruct(self):
        # Needed so Django's migration system doesn't try to serialize a
        # live GitHubCDNStorage() instance into the migration file itself.
        name, path, args, kwargs = super().deconstruct()
        kwargs.pop("storage", None)
        return name, path, args, kwargs
