"""
views.py (example usage)

From the end user's point of view this is just an ordinary file upload
form. Internally, the file never touches Django's local/media storage —
it's committed straight to GitHub and only the resulting CDN URL is
persisted in the database.
"""
from django import forms
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

from .models import GitHubConfig, UploadedImage
from .services import upload_image_to_github, GitHubUploadError


class ImageUploadForm(forms.Form):
    image = forms.ImageField()  # ordinary Django ImageField — validation only, not storage


@login_required
def upload_image_view(request):
    """
    Assumes `request.tenant` is already set by your tenant-resolution
    middleware (e.g. from subdomain or path, same mechanism you'd use for
    django-tenants or a custom TenantMiddleware).
    """
    if request.method == "POST":
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.cleaned_data["image"]

            try:
                config = GitHubConfig.objects.get(tenant=request.tenant, is_active=True)
            except GitHubConfig.DoesNotExist:
                form.add_error(None, "Image uploads aren't configured for this account yet.")
                return render(request, "uploads/upload_form.html", {"form": form})

            try:
                result = upload_image_to_github(
                    config=config,
                    file_obj=uploaded_file.file,
                    original_filename=uploaded_file.name,
                )
            except GitHubUploadError as exc:
                form.add_error(None, f"Upload failed: {exc}")
                return render(request, "uploads/upload_form.html", {"form": form})

            record = UploadedImage.objects.create(
                tenant=request.tenant,
                original_filename=uploaded_file.name,
                github_path=result["path"],
                cdn_url=result["cdn_url_branch"],
                content_type=uploaded_file.content_type,
                size_bytes=result["size"],
            )

            # Wherever the rest of your app needs the image (blog post cover,
            # bookmark thumbnail, profile avatar), reference `record.cdn_url`
            # or `record.id` via a ForeignKey — never a local file path.
            return redirect("uploads:detail", pk=record.pk)
    else:
        form = ImageUploadForm()

    return render(request, "uploads/upload_form.html", {"form": form})
