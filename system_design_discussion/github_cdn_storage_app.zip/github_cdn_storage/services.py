"""
services.py

Direct GitHub Contents API integration. This replaces
`https://picser.pages.dev/api/public-upload` entirely — your Django
backend talks to GitHub directly, so your token never transits a
third-party service.

Docs: https://docs.github.com/en/rest/repos/contents
"""
import base64
import uuid
import requests
from django.utils.text import slugify


class GitHubUploadError(Exception):
    pass


def _unique_filename(original_name: str) -> str:
    """Avoid collisions without needing a GitHub API round-trip to check existence."""
    stem, _, ext = original_name.rpartition(".")
    stem = slugify(stem) or "file"
    ext = ext.lower() or "bin"
    return f"{stem}-{uuid.uuid4().hex[:10]}.{ext}"


def upload_image_to_github(config, file_obj, original_filename: str) -> dict:
    """
    Uploads `file_obj` (any file-like object opened in binary mode) to the
    tenant's configured GitHub repo, and returns CDN URL info.

    `config` is a GitHubConfig instance (see models.py) — carries the
    token, owner, repo, branch, and target folder for this tenant.
    """
    filename = _unique_filename(original_filename)
    folder = config.upload_folder.strip("/")
    path = f"{folder}/{filename}" if folder else filename

    file_obj.seek(0)
    raw_bytes = file_obj.read()
    b64_content = base64.b64encode(raw_bytes).decode()

    api_url = (
        f"https://api.github.com/repos/"
        f"{config.github_owner}/{config.github_repo}/contents/{path}"
    )
    headers = {
        "Authorization": f"Bearer {config.github_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    payload = {
        "message": f"Upload {filename}",
        "content": b64_content,
        "branch": config.github_branch,
    }

    resp = requests.put(api_url, json=payload, headers=headers, timeout=20)
    if resp.status_code not in (200, 201):
        raise GitHubUploadError(
            f"GitHub upload failed ({resp.status_code}): {resp.text[:300]}"
        )

    data = resp.json()
    commit_sha = data["commit"]["sha"]

    owner, repo, branch = config.github_owner, config.github_repo, config.github_branch

    return {
        "path": path,
        "filename": filename,
        "size": len(raw_bytes),
        "commit_sha": commit_sha,
        # Branch-pinned: stable to reconstruct later from just (owner, repo, branch, path).
        # Cache may lag a few minutes behind a new commit on the same path — fine for
        # avatars/thumbnails, not fine if you need instant-consistency reads.
        "cdn_url_branch": f"https://cdn.jsdelivr.net/gh/{owner}/{repo}@{branch}/{path}",
        # Commit-pinned: permanent and cache-immutable, but only reconstructable if you
        # also store `commit_sha` somewhere (which UploadedImage does).
        "cdn_url_commit": f"https://cdn.jsdelivr.net/gh/{owner}/{repo}@{commit_sha}/{path}",
        "raw_url": f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}",
    }


def delete_image_from_github(config, path: str, sha: str, message: str = "Delete image"):
    """
    GitHub's delete endpoint requires the blob's current `sha`. Fetch it
    first with a GET if you don't already have it stored.
    """
    api_url = (
        f"https://api.github.com/repos/"
        f"{config.github_owner}/{config.github_repo}/contents/{path}"
    )
    headers = {
        "Authorization": f"Bearer {config.github_token}",
        "Accept": "application/vnd.github+json",
    }
    payload = {"message": message, "sha": sha, "branch": config.github_branch}
    resp = requests.delete(api_url, json=payload, headers=headers, timeout=20)
    if resp.status_code not in (200,):
        raise GitHubUploadError(
            f"GitHub delete failed ({resp.status_code}): {resp.text[:300]}"
        )
