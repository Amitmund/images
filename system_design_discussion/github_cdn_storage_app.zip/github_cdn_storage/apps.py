from django.apps import AppConfig


class GithubCdnStorageConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "github_cdn_storage"
