"""
models.py

One GitHubConfig row per tenant. The token is encrypted at rest using
Fernet (symmetric encryption) rather than stored as plain text — a leaked
DB backup should not hand out live GitHub tokens for every tenant.

Requires: pip install cryptography --break-system-packages
Requires a GITHUB_TOKEN_ENCRYPTION_KEY in settings (generate once with
`Fernet.generate_key()` and store it in your secrets manager / .env,
never in source control).
"""
from django.db import models
from django.conf import settings
from cryptography.fernet import Fernet


def _get_fernet():
    key = settings.GITHUB_TOKEN_ENCRYPTION_KEY
    if isinstance(key, str):
        key = key.encode()
    return Fernet(key)


class GitHubConfig(models.Model):
    """
    Per-tenant GitHub upload target. Swap the ForeignKey below to point at
    whatever your actual tenant model is (e.g. `tenants.Tenant`).
    """
    tenant = models.OneToOneField(
        "tenants.Tenant",  # adjust to your real tenant model path
        on_delete=models.CASCADE,
        related_name="github_config",
    )

    _github_token = models.BinaryField(db_column="github_token")
    github_owner = models.CharField(max_length=255)
    github_repo = models.CharField(max_length=255)
    github_branch = models.CharField(max_length=100, default="main")
    upload_folder = models.CharField(max_length=255, default="uploads")

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "GitHub Upload Config"

    def __str__(self):
        return f"{self.tenant} -> {self.github_owner}/{self.github_repo}"

    @property
    def github_token(self):
        return _get_fernet().decrypt(bytes(self._github_token)).decode()

    @github_token.setter
    def github_token(self, raw_token):
        self._github_token = _get_fernet().encrypt(raw_token.encode())


class UploadedImage(models.Model):
    """
    One row per uploaded image. This is what the rest of your app should
    reference (e.g. ForeignKey from a Post, Bookmark, or Profile model) —
    not a raw ImageField — since the actual bytes live on GitHub, not on
    your Django server's disk.
    """
    tenant = models.ForeignKey(
        "tenants.Tenant",  # adjust to your real tenant model path
        on_delete=models.CASCADE,
        related_name="uploaded_images",
    )
    original_filename = models.CharField(max_length=255)
    github_path = models.CharField(max_length=500)
    cdn_url = models.URLField(max_length=600)
    content_type = models.CharField(max_length=100, blank=True)
    size_bytes = models.PositiveIntegerField(null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.original_filename
