# Setup Notes

## 1. Add to INSTALLED_APPS
```python
INSTALLED_APPS = [
    ...
    "github_cdn_storage",
]
```

## 2. Generate an encryption key (once, per environment)
```python
from cryptography.fernet import Fernet
print(Fernet.generate_key().decode())
```
Put the output in your environment/secrets manager, then in settings.py:
```python
import os
GITHUB_TOKEN_ENCRYPTION_KEY = os.environ["GITHUB_TOKEN_ENCRYPTION_KEY"]
```
Never commit this key. If it's lost, every stored GitHub token becomes
undecryptable — treat it like a master password.

## 3. Wire up the tenant model reference
`models.py` has two `ForeignKey("tenants.Tenant", ...)` placeholders —
point these at whatever your real tenant model is.

## 4. Per-tenant setup (e.g. via Django admin or a management command)
```python
config = GitHubConfig(
    tenant=some_tenant,
    github_owner="your_github_username_or_org",
    github_repo="tenant-assets-public",   # a PUBLIC repo dedicated to uploads
    github_branch="main",
    upload_folder="uploads",
)
config.github_token = "ghp_xxx..."   # triggers the Fernet encryption setter
config.save()
```

## 5. Token scope
Use a **fine-grained personal access token** scoped to only that one repo,
with:
- Contents: Read and write
- Metadata: Read-only

Avoid classic tokens with blanket `repo` scope if you can — fine-grained
tokens limit the blast radius if one ever leaks.

## 6. requirements.txt additions
```
requests
cryptography
```

## Architecture summary

```
User submits form
      │
      ▼
Django view (upload_image_view)
      │  reads request.tenant → looks up GitHubConfig
      ▼
services.upload_image_to_github()
      │  PUTs file bytes directly to GitHub Contents API
      │  (your token never leaves your server)
      ▼
GitHub commits the file to the tenant's public assets repo
      │
      ▼
jsDelivr mirrors the public repo automatically (no action needed)
      │
      ▼
UploadedImage row saved with the resulting cdn_url
      │
      ▼
Rest of your app just uses record.cdn_url like any other image URL
```

No self-hosted Picser clone, no third-party hop — this is strictly a
subset of what Picser does, running inside your own Django process.
